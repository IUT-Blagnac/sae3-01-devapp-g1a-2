package model.orm;

import java.io.File;
import java.io.IOException;

public class accessAppPython {
	
	private Process processPython;
	

	/**
	 * Lance l'application python sur un processus.
	 * 
	 * @return le processus sur lequel tourne le programme python
	 */
	public Process startPythonApp() {
		try {
			File f = new File("src/model/data/app.py");
			ProcessBuilder builder = new ProcessBuilder("python",f.getAbsolutePath());
			this.processPython = builder.start();
			
		

			/*
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String lines = null;
			while((lines=reader.readLine())!=null) {
				System.out.println(lines);
			}*/
		} catch (IOException e) {

			e.printStackTrace();
		}
		return this.processPython;

	}

	/**
	 * Fini le processus sur lequel fonctionne l'application python
	 */
	public void stopPythonApp() {
		this.processPython.destroy();
	}
}
