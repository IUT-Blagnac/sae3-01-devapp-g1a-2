package application.view;

import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Timer;

import application.controller.NoskiaMainFrame;
import application.tools.AlertUtilities;
import application.tools.TaskBackground;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class NoskiaMainFrameController implements Initializable {
	private Stage primaryStage;
	private NoskiaMainFrame nmf;
	
	private TaskBackground tb;
	private Timer timer;
	
	private Series<String, Number> dataSerie;
	private Boolean isDataChoisi = false;
	
	
	
	/**
	 * Initialise le contexte de la page (la fenêtre principale de la page, le controller) et lance la configuration de la page.
	 * 
	 * @param _containingStage la fenêtre princiaple
	 * @param _NoskiaMainFrame le controller de la fenêtre principale
	 */
	public void initContext(Stage _containingStage, NoskiaMainFrame _NoskiaMainFrame) {
		this.primaryStage = _containingStage;
		this.nmf = _NoskiaMainFrame;
		this.configure();
	}
	
	
	
	/**
	 * Configure la page (ajout d'une fonction à l'évènement de fermeture de la page).
	 * 
	 * Lance la gestion du menu
	 */
	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
		this.barchart.setAnimated(false);
		this.headerManagement();
	}
	
	/**
	 * Affichage le contenu de la page
	 * 
	 * Initialise la séries du données du graphique et paramètre le graphique (retire la légende)
	 */
	public void displayDialog() {
		this.primaryStage.show();

		this.dataSerie = new XYChart.Series<String, Number>();

		this.barchart.getData().add(this.dataSerie);
		this.barchart.setLegendVisible(false);
		
		/*
		this.containerBarChart.getChildren().add(this.barchart);
		
		Line line = new Line();
		line.setStartX(200);
		line.setEndX(this.barchart.getWidth());
		line.setStartY(50);
		line.setEndY(50);
		line.setStrokeWidth(2);
		line.setStroke(Color.BLACK);
		
		
		this.containerBarChart.getChildren().add(line);*/
		
	}
	
	/**
	 * Lance un timer s'il n'en existe pas déjà un. 
	 * Lance l'application python
	 */
	public void startTimer() {
		if (this.tb == null) {
			this.tb = new TaskBackground(this);
			this.timer = new Timer();
			this.timer.schedule(tb, 1000L, 2000L);
		}
		this.nmf.doStartPythonApp();
	}
	
	/**
	 * Lancé par la fermeture de la page.
	 * 
	 * Lance la fonction de fermeture et consumme l'évènement
	 */
	private Object closeWindow(WindowEvent e) {
		this.doQuit();
		e.consume();
		return null;
	}

	
	@FXML
	private SplitMenuButton LD_salle;
	@FXML
	private MenuItem LD_salle_B201;
	@FXML
	private MenuItem LD_salle_B202;
	@FXML
	private MenuItem LD_salle_B203;
	@FXML
	private MenuItem LD_salle_B110;
	@FXML
	private MenuItem LD_salle_B111;
	
	@FXML
	private Label title;
	
	@FXML
	private Label gridName ;
	@FXML
	private Button b_co2;
	@FXML
	private Button b_temperature;
	@FXML
	private Button b_humidity;
	@FXML
	private Button b_pressure;
	@FXML
	private Button b_illumination;
	@FXML
	private Button b_infrared;
	@FXML
	private Button b_infrared_and_visible;
	@FXML
	private Button b_tvoc;
	@FXML
	private Button b_activity;
	
	@FXML
	private Button b_configurer;
	
	@FXML
	private Pane alertPane;
	
	@FXML
	private Pane dataPane;
	@FXML
	private Label derniereData;
	
	@FXML
	private BarChart<String, Number> barchart;
	@FXML
	private Label barchartName;
	/*
	@FXML
	private Pane containerBarChart;*/
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {	
	}
	
	/**
	 * Affiche un popup de demande de confirmation pour quitter la page
	 * 
	 * Si oui, la page et quitté, sinon elle reste ouverte. A la fermeture, on termine l'exécution du timer et de l'application python.
	 */
	@FXML
	private void doQuit() {
		if (AlertUtilities.confirmYesCancel(this.primaryStage, "Quitter Appli Principale",
				"Etes vous sur de vouloir quitter l'appli ?", null, AlertType.CONFIRMATION)) {
			this.primaryStage.close();
			if(this.tb != null) {
				this.timer.cancel();
			}
			this.nmf.doStopPythonApp();
		}
	}
	
	/**
	 * S'active à la pression du bouton du bouton "configuration"
	 * 
	 * Permet de la lancer l'ouverture de la page de configuration
	 */
	@FXML
	private void doConfiguration() {
		this.nmf.startConfiguration();
	}
	

	
	
	/**
	 * Permet d'actualiser la liste déroulante, le titre de la page et le choix des données en fonction du choix de la salle.
	 * 
	 * Retire le contenu de la page tant qu'un choix de la liste déroulant n'est pas sélectionné. Et lance l'affichage du contenu lorsqu'une salle est selectionnée
	 * 
	 * Lance la gestion du contenu.
	 */
	private void headerManagement() {
		unseeContent();
		this.LD_salle_B201.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B201.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B201.getText());
		    this.isDataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B202.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B202.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B202.getText());
		    this.isDataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B203.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B203.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B203.getText());
		    this.isDataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B110.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B110.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B110.getText());
		    this.isDataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B111.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B111.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B111.getText());
		    this.isDataChoisi = false;
		    seeContent();
		});
		contentManagement();
	}
	
	/**
	 * Gestion du contenu : A la pression d'un des boutons de donnée,change le titre du graphe, retire les données précédente du graphe et lance l'affichage du contenu
	 */
	private void contentManagement() {
		this.b_activity.setOnAction((e) -> {
			this.barchartName.setText(this.b_activity.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_co2.setOnAction((e) -> {
			this.barchartName.setText(this.b_co2.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_humidity.setOnAction((e) -> {
			this.barchartName.setText(this.b_humidity.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_illumination.setOnAction((e) -> {
			this.barchartName.setText(this.b_illumination.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_infrared.setOnAction((e) -> {
			this.barchartName.setText(this.b_infrared.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_infrared_and_visible.setOnAction((e) -> {
			this.barchartName.setText(this.b_infrared_and_visible.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_pressure.setOnAction((e) -> {
			this.barchartName.setText(this.b_pressure.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_temperature.setOnAction((e) -> {
			this.barchartName.setText(this.b_temperature.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
		this.b_tvoc.setOnAction((e) -> {
			this.barchartName.setText(this.b_tvoc.getText());
			this.dataSerie.getData().clear();
			this.isDataChoisi = true;
			seeContent();
		});
	}

	/**
	 * Retire le contenu de la page d'accueil
	 */
	private void unseeContent() {

		this.gridName.setVisible(false);
		this.b_activity.setVisible(false);
		this.b_co2.setVisible(false);
		this.b_illumination.setVisible(false);
		this.b_infrared.setVisible(false);
		this.b_infrared_and_visible.setVisible(false);
		this.b_pressure.setVisible(false);
		this.b_tvoc.setVisible(false);
		this.b_humidity.setVisible(false);
		this.b_temperature.setVisible(false);
		
		this.barchart.setVisible(false);
		this.barchartName.setVisible(false);
		this.dataPane.setVisible(false);
		
		this.alertPane.setVisible(false);
		
		this.b_configurer.setVisible(false);
		
	}
	
	/**
	 * Gère l'affichage progressif des éléments de la page d'acceuil.
	 * 
	 * Affiche les boutons et alertes lorsqu'une salle est selectionnée.
	 * Affiche le graphe et l'information sur les données lorsqu'un type de donnée est choisi.
	 */
	private void seeContent() {
		Map<String, Boolean> selectedData = this.nmf.getSelectedData();
		this.gridName.setVisible(true);
		if (selectedData.get("co2") == true) {
			this.b_co2.setVisible(true);
		}
		if (selectedData.get("activity") == true) {
			this.b_activity.setVisible(true);
		}
		if (selectedData.get("illumination") == true) {
			this.b_illumination.setVisible(true);
		}
		if (selectedData.get("infrared") == true) {
			this.b_infrared.setVisible(true);
		}
		if (selectedData.get("infrared_and_visible") == true) {
			this.b_infrared_and_visible.setVisible(true);
		}
		if (selectedData.get("pressure") == true) {
			this.b_pressure.setVisible(true);
		}
		if (selectedData.get("humidity") == true) {
			this.b_humidity.setVisible(true);
		}
		if (selectedData.get("tvoc") == true) {
			this.b_tvoc.setVisible(true);
		}
		if (selectedData.get("temperature") == true) {
			this.b_temperature.setVisible(true);
		}
		
		
		if(this.isDataChoisi == true) {
			this.barchart.setVisible(true);
			this.barchartName.setVisible(true);
			this.dataPane.setVisible(true);
			this.nmf.doStartTimer();
		} else {
			this.barchart.setVisible(false);
			this.barchartName.setVisible(false);
			this.dataPane.setVisible(false);
			this.derniereData.setText("");
		}
		this.alertPane.setVisible(true);
		this.b_configurer.setVisible(true);
		
		
	}
	
	/**
	 * Met à jour le graphe de donnée avec la date de la dernière donnée reçu et la valeur.
	 * 
	 * @param date la date de la donnée reçu
	 * @param valeur la valeur de la donnée reçu
	 */
	public void misteAJourBarChart(String date, int valeur){
		this.dataSerie.getData().add(new XYChart.Data<String, Number>(date, valeur));
		 for(Data<String, Number> data : this.dataSerie.getData())
         {
			 if(data.getYValue().intValue()>80) {
				 data.getNode().setStyle("-fx-bar-fill: firebrick;");
			 } else {
				 data.getNode().setStyle("-fx-bar-fill: #47b431;");
			 }
             
         } 
		if(this.dataSerie.getData().size()>8) {
			this.dataSerie.getData().remove(0);
		}
		this.derniereData.setText("Date : "+date+" // Valeur  : "+valeur);
	
	}

	/**
	 * Actualise l'affichage de la page (utilisé lorsque l'on modifier la configuration en pleine exécution).
	 */
	public void actualiserAffichageParametre() {
		this.unseeContent();
		this.seeContent();
	}
	
}
