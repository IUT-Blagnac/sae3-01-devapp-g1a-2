package application.view;

import java.net.URL;
import java.util.ResourceBundle;

import application.controller.NoskiaMainFrame;
import application.tools.AlertUtilities;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class NoskiaMainFrameController implements Initializable {
	private Stage primaryStage;
	private NoskiaMainFrame nmf;
	
	/**
	 * Initialise le contexte de la page (la fenêtre principale de la page, le controller) et lance la configuration de la page.
	 * 
	 * @param _containingStage la fenêtre princiaple
	 * @param _NoskiaMainFrame le controller de la fenêtre principale
	 */
	public void initContext(Stage _containingStage, NoskiaMainFrame _NoskiaMainFrame) {
		this.primaryStage = _containingStage;
		this.nmf = _NoskiaMainFrame;
		this.configure();
	}
	
	/**
	 * Configure la page (ajout d'une fonction à l'évènement de fermeture de la page).
	 */
	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
	}
	
	/**
	 * Lancé par la fermeture de la page.
	 * 
	 * Lance la fonction de fermeture et consumme l'évènement
	 */
	private Object closeWindow(WindowEvent e) {
		this.doQuit();
		e.consume();
		return null;
	}

	

	
	@Override
	public void initialize(URL location, ResourceBundle resources) {	
	}
	
	/**
	 * Affiche un popup de demande de confirmation pour quitter la page
	 * 
	 * Si oui, la page et quitté, sinon elle reste ouverte.
	 */
	@FXML
	private void doQuit() {
		if (AlertUtilities.confirmYesCancel(this.primaryStage, "Quitter Appli Principale",
				"Etes vous sur de vouloir quitter l'appli ?", null, AlertType.CONFIRMATION)) {
			this.primaryStage.close();
		}
	}
	
	/**
	 * S'active à la pression du bouton du bouton "configuration"
	 * 
	 * Permet de la lancer l'ouverture de la page de configuration
	 */
	@FXML
	private void doConfiguration() {
		this.nmf.startConfiguration();
	}
	
	

	
}
