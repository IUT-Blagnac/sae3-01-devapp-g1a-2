package application.view;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;

import application.controller.NoskiaMainFrame;
import application.tools.AlertUtilities;
import application.tools.TaskBackground;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class NoskiaMainFrameController implements Initializable {
	private Stage primaryStage;
	private NoskiaMainFrame nmf;
	
	private TaskBackground tb;
	private Timer timer;
	
	private Series<String, Number> dataSerie;
	private Boolean dataChoisi = false;
	
	
	
	/**
	 * Initialise le contexte de la page (la fenêtre principale de la page, le controller) et lance la configuration de la page.
	 * 
	 * @param _containingStage la fenêtre princiaple
	 * @param _NoskiaMainFrame le controller de la fenêtre principale
	 */
	public void initContext(Stage _containingStage, NoskiaMainFrame _NoskiaMainFrame) {
		this.primaryStage = _containingStage;
		this.nmf = _NoskiaMainFrame;
		this.configure();
	}
	
	
	
	/**
	 * Configure la page (ajout d'une fonction à l'évènement de fermeture de la page).
	 */
	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
		this.barchart.setAnimated(false);
		this.headerManagement();
	}
	
	public void displayDialog() {
		this.primaryStage.show();
		
		
		
		
		this.dataSerie = new XYChart.Series<String, Number>();
		

		
		
		this.barchart.getData().add(this.dataSerie);
		
		/*
		this.containerBarChart.getChildren().add(this.barchart);
		
		Line line = new Line();
		line.setStartX(200);
		line.setEndX(this.barchart.getWidth());
		line.setStartY(50);
		line.setEndY(50);
		line.setStrokeWidth(2);
		line.setStroke(Color.BLACK);
		
		
		this.containerBarChart.getChildren().add(line);*/
		
		
		

		

	}
	
	private void startTimer() {
		if (this.tb == null) {
			this.tb = new TaskBackground(this);
			this.timer = new Timer();
			this.timer.schedule(tb, 1000L, 2000L);
		}
		
	}
	
	/**
	 * Lancé par la fermeture de la page.
	 * 
	 * Lance la fonction de fermeture et consumme l'évènement
	 */
	private Object closeWindow(WindowEvent e) {
		this.doQuit();
		e.consume();
		return null;
	}

	
	@FXML
	private SplitMenuButton LD_salle;
	@FXML
	private MenuItem LD_salle_B201;
	@FXML
	private MenuItem LD_salle_B202;
	@FXML
	private MenuItem LD_salle_B203;
	@FXML
	private MenuItem LD_salle_B110;
	@FXML
	private MenuItem LD_salle_B111;
	
	@FXML
	private Label title;
	
	@FXML
	private Label gridName ;
	@FXML
	private Button b_co2;
	@FXML
	private Button b_temperature;
	@FXML
	private Button b_humidite;
	@FXML
	private Button b_pression;
	@FXML
	private Button b_illumination;
	@FXML
	private Button b_infrarouge;
	@FXML
	private Button b_infrarouge_visible;
	@FXML
	private Button b_tvoc;
	@FXML
	private Button b_activite;
	
	@FXML
	private Button b_configurer;
	
	@FXML
	private Pane alertPane;
	
	@FXML
	private Pane dataPane;
	@FXML
	private Label derniereData;
	
	@FXML
	private BarChart<String, Number> barchart;
	@FXML
	private Label barchartName;
	/*
	@FXML
	private Pane containerBarChart;*/
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {	
	}
	
	/**
	 * Affiche un popup de demande de confirmation pour quitter la page
	 * 
	 * Si oui, la page et quitté, sinon elle reste ouverte.
	 */
	@FXML
	private void doQuit() {
		if (AlertUtilities.confirmYesCancel(this.primaryStage, "Quitter Appli Principale",
				"Etes vous sur de vouloir quitter l'appli ?", null, AlertType.CONFIRMATION)) {
			this.primaryStage.close();
			if(this.tb != null) {
				this.timer.cancel();
			}
			
		}
	}
	
	/**
	 * S'active à la pression du bouton du bouton "configuration"
	 * 
	 * Permet de la lancer l'ouverture de la page de configuration
	 */
	@FXML
	private void doConfiguration() {
		this.nmf.startConfiguration();
	}
	

	
	
	/**
	 * Permet d'actualiser la liste déroulante, le titre de la page et le choix des données en fonction du choix de la salle
	 */
	private void headerManagement() {
		unseeContent();
		this.LD_salle_B201.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B201.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B201.getText());
		    this.dataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B202.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B202.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B202.getText());
		    this.dataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B203.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B203.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B203.getText());
		    this.dataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B110.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B110.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B110.getText());
		    this.dataChoisi = false;
		    seeContent();
		});
		this.LD_salle_B111.setOnAction((e)-> {
		    this.LD_salle.setText(this.LD_salle_B111.getText());
		    this.title.setText("Données de la salle "+this.LD_salle_B111.getText());
		    this.dataChoisi = false;
		    seeContent();
		});
		contentManagement();
	}
	
	private void contentManagement() {
		this.b_activite.setOnAction((e) -> {
			this.barchartName.setText(this.b_activite.getText());
			this.dataSerie.setName(this.b_activite.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_co2.setOnAction((e) -> {
			this.barchartName.setText(this.b_co2.getText());
			this.dataSerie.setName(this.b_co2.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_humidite.setOnAction((e) -> {
			this.barchartName.setText(this.b_humidite.getText());
			this.dataSerie.setName(this.b_humidite.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_illumination.setOnAction((e) -> {
			this.barchartName.setText(this.b_illumination.getText());
			this.dataSerie.setName(this.b_illumination.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_infrarouge.setOnAction((e) -> {
			this.barchartName.setText(this.b_infrarouge.getText());
			this.dataSerie.setName(this.b_infrarouge.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_infrarouge_visible.setOnAction((e) -> {
			this.barchartName.setText(this.b_infrarouge_visible.getText());
			this.dataSerie.setName(this.b_infrarouge_visible.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_pression.setOnAction((e) -> {
			this.barchartName.setText(this.b_pression.getText());
			this.dataSerie.setName(this.b_activite.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_temperature.setOnAction((e) -> {
			this.barchartName.setText(this.b_temperature.getText());
			this.dataSerie.setName(this.b_temperature.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
		this.b_tvoc.setOnAction((e) -> {
			this.barchartName.setText(this.b_tvoc.getText());
			this.dataSerie.setName(this.b_tvoc.getText());
			this.dataSerie.getData().clear();
			this.dataChoisi = true;
			seeContent();
		});
	}

	/**
	 * retire le contenu de la page d'acceuil
	 */
	private void unseeContent() {
		this.gridName.setVisible(false);
		this.b_activite.setVisible(false);
		this.b_co2.setVisible(false);
		this.b_illumination.setVisible(false);
		this.b_infrarouge.setVisible(false);
		this.b_infrarouge_visible.setVisible(false);
		this.b_pression.setVisible(false);
		this.b_tvoc.setVisible(false);
		this.b_humidite.setVisible(false);
		this.b_temperature.setVisible(false);
		
		this.barchart.setVisible(false);
		this.barchartName.setVisible(false);
		this.dataPane.setVisible(false);
		
		this.alertPane.setVisible(false);
		
		this.b_configurer.setVisible(false);
		
	}
	
	/**
	 * Affiche le contenu de la page d'acceuil en fonction de quel option de la liste déroulante l'utilisateur choisi (la salle choisi)
	 */
	private void seeContent() {
		this.gridName.setVisible(true);
		this.b_activite.setVisible(true);
		this.b_co2.setVisible(true);
		this.b_illumination.setVisible(true);
		this.b_infrarouge.setVisible(true);
		this.b_infrarouge_visible.setVisible(true);
		this.b_pression.setVisible(true);
		this.b_tvoc.setVisible(true);
		this.b_humidite.setVisible(true);
		this.b_temperature.setVisible(true);
		
		if(this.dataChoisi == true) {
			this.barchart.setVisible(true);
			this.barchartName.setVisible(true);
			this.dataPane.setVisible(true);
			startTimer();
		} else {
			this.barchart.setVisible(false);
			this.barchartName.setVisible(false);
			this.dataPane.setVisible(false);
			this.derniereData.setText("");
		}
		this.alertPane.setVisible(true);
		this.b_configurer.setVisible(true);
		
		
	}
	
	public void misteAJourBarChart(String date, int valeur){
		this.dataSerie.getData().add(new XYChart.Data<String, Number>(date, valeur));
		if(this.dataSerie.getData().size()>8) {
			this.dataSerie.getData().remove(0);
		}
		this.derniereData.setText("Date : "+date+" // Valeur  : "+valeur);
	
	}









	

	
	
}
