package application.tools;

import java.util.Optional;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class AlertUtilities {
	

	/**
	 * Permet de créer et d'ouvrir un pop-up d'information.
	 * 
	 * Ce pop-up peut soit être confirmé ou annulé.
	 * 
	 * @param _fen la fenêtre parent qui appelle celle ci
	 * @param _title titre de la page
	 * @param _message le titre du message
	 * @param _content le contenu du message
	 * @param _al le type de l'alerte
	 * 
	 * @return true si l'utilisateur confirme et false sinon
	 */
	public static boolean confirmYesCancel(Stage _fen, String _title, String _message, String _content, AlertType _al) {

		if (_al == null) {
			_al = AlertType.INFORMATION;
		}
		Alert alert = new Alert(_al);
		alert.initOwner(_fen);
		alert.setTitle(_title);
		if (_message == null || !_message.equals(""))
			alert.setHeaderText(_message);
		alert.setContentText(_content);

		Optional<ButtonType> option = alert.showAndWait();
		if (option.isPresent() && option.get() == ButtonType.OK) {
			return true;
		}
		return false;
	}

	/**
	 * Permet de créer et d'ouvrir un pop-up d'information.
	 * 
	 * Cette alerte ne pourra qu'être accepté, elle s'utilise pour diffuser une information.
	 * 
	 * @param _fen la fenêtre parent qui appelle celle ci
	 * @param _title titre de la page
	 * @param _message le titre du message
	 * @param _content le contenu du message
	 * @param _al le type de l'alerte
	 */
	public static void showAlert(Stage _fen, String _title, String _message, String _content, AlertType _al) {

		if (_al == null) {
			_al = AlertType.INFORMATION;
		}
		Alert alert = new Alert(_al);
		alert.initOwner(_fen);
		alert.setTitle(_title);
		if (_message == null || !_message.equals(""))
			alert.setHeaderText(_message);
		alert.setContentText(_content);

		alert.showAndWait();
	}
}
