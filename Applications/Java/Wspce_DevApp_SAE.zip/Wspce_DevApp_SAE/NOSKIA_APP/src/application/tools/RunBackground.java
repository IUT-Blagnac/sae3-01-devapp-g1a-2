package application.tools;

import application.view.NoskiaMainFrameController;
import javafx.application.Platform;
import javafx.scene.chart.XYChart.Series;

public class RunBackground implements Runnable{
	private boolean isRun;
	
	private NoskiaMainFrameController nmfc;
	private Series<String, Number> normalSeries;

	public RunBackground(NoskiaMainFrameController _nmfc,Series<String, Number>_s) {
		this.nmfc = _nmfc;
		this.normalSeries = _s;
	}
	
	@Override
	public void run() {
		while (this.isRun) {
			int value = (int) (Math.random() * 100);
			String name = ""+(int) (Math.random() * 100);


			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					RunBackground.this.nmfc.misteAJourBarChart(name, value, RunBackground.this.normalSeries);
				}
			});

			try {
				Thread.sleep(3000L);
			} catch (InterruptedException e) {
			}
		}
		
	}

	
	public void stopIt() {
		this.isRun = false;
	}

}
