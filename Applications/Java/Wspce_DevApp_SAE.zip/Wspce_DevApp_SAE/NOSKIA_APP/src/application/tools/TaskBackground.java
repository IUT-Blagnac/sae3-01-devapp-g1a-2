package application.tools;

import java.util.TimerTask;

import application.view.NoskiaMainFrameController;
import javafx.application.Platform;

public class TaskBackground extends TimerTask{
	private NoskiaMainFrameController nmfc;
	
	private int c = 0;
	
	/**
	 * Constructeur paramétrique
	 * 
	 * @param _nmfc le controller qui va créer des timer
	 */
	public TaskBackground(NoskiaMainFrameController _nmfc) {
		this.nmfc = _nmfc;
	}

	/**
	 * Permet de mettre à jour les données dans un thread différent du principale.
	 */
	@Override
	public void run() {
		 int value = (int) (Math.random() * 100);
	        String name = "t"+c;
	        c++;

		
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				TaskBackground.this.nmfc.misteAJourBarChart(name, value);
			}
		});
	}

}
