package application.tools;

import java.util.TimerTask;

import application.view.NoskiaMainFrameController;
import javafx.application.Platform;
import javafx.scene.chart.XYChart.Series;

public class TaskBackground extends TimerTask{
	private NoskiaMainFrameController nmfc;
	private Series<String, Number> normalSeries;
	
	
	public TaskBackground(NoskiaMainFrameController _nmfc,Series<String, Number>_s) {
		this.nmfc = _nmfc;
		this.normalSeries = _s;
	}

	@Override
	public void run() {
		int value = (int) (Math.random() * 100);
		String name = ""+(int) (Math.random() * 100);
		Series<String, Number> series = this.normalSeries;
		
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				TaskBackground.this.nmfc.misteAJourBarChart(name, value, TaskBackground.this.normalSeries);
			}
		});
	}

}
