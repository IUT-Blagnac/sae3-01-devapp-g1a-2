package application.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import application.tools.StageManagement;
import application.view.FichierConfigController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;


import org.ini4j.Ini;
import org.ini4j.InvalidFileFormatException;

public class FichierConfig {
	private FichierConfigController fcc;
	private Stage primaryStage;
	private NoskiaMainFrame nfm;

	/**
	 * Contructeur paramétrique 
	 * 
	 * Génére la fenêtre via le fichier FXML, initialise son contexte et sa configuration
	 * 
	 * Intiliase l'attribut nfm (NoskiaMainFrame)
	 * 
	 * @param _parentStage la fenêtre parent qui ouvre celle ci
	 * @param _nfm le controller de la fenêtre principale.
	 */
	public FichierConfig(Stage _parentStage, NoskiaMainFrame _nfm) {
		try {
			FXMLLoader loader = new FXMLLoader(FichierConfigController.class.getResource("../view/FichierConfigPane.fxml"));
			AnchorPane root = loader.load();

			Scene scene = new Scene(root);

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Gestion du fichier de configuration");
			this.primaryStage.setResizable(false);

			this.nfm = _nfm;
			
			this.fcc = loader.getController();
			this.fcc.initContext(this.primaryStage, this);
			
			this.fcc.loadConfiguration(this.getWantedData(), this.getSeuils(), this.getFrequence());
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Appelle la fonction qui va afficher la fenêtre, est appellé par la page parent (page d'acceuil)
	 */
	public void doConfigurationFichierConfig() {
		this.fcc.displayDialog();
	}
	
	/**
	 * Récupère les informations envoyé par la classe de gestion de la vue 
	 * et les enregistre dans le fichier config.ini de la partie model.
	 * 
	 * @param wantedData les données de la partie  "donnée récupérer" du formulaire (données que l'on veut afficher)
	 * @param seuils les données de la partie "seuils" du formulaire
	 * @param freq la fréquence à laquelle on récupère les données
	 * 
	 */
	public void doSaveConfiguration(Map<String, Boolean> wantedData, Map<String, String> seuils, String freq) {
		try {
			Ini ini = new Ini(new File("src/model/data/config.ini"));
			for(Entry<String, Boolean> e : wantedData.entrySet()) {
				ini.put("data",e.getKey(),e.getValue() );
			}
			
			for(Entry<String, String> e : seuils.entrySet()) {
				if(!e.getValue().equals("")) {
					ini.put("seuils",e.getKey(),e.getValue() );
				}
			}
			
			if(!freq.equals("")) {
				ini.put("frequences","freq-1",freq );
			}
			
			ini.store();
			this.nfm.doActualiserAffichageParametre();
		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Récupère les valeurs de la partie "data" du fichier config.ini
	 * 
	 * Utilisé pour rechargé le paramétrage précédent des valeurs
	 * 
	 * @return HashMap la map des valeurs
	 */
	public Map<String, Boolean> getWantedData() {
		Map<String, Boolean> res = new HashMap<String, Boolean>();
		try {
			Ini ini = new Ini(new File("src/model/data/config.ini"));
			for(String key : ini.get("data").keySet()) {
				String value = ini.get("data", key);
				if(!key.equals("data_choisi")) {
					if(value.equals("true")) {
						res.put(key, true);
					} else {
						res.put(key, false);
					}
				}
			}
		} catch (InvalidFileFormatException e)  {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return res;
		
	}
	
	/**
	 * Récupère les valeurs de la partie "seuils" du fichier config.ini
	 * 
	 * Utilisé pour rechargé le paramétrage précédent des valeurs
	 * 
	 * @return HashMap la map des valeurs
	 */
	public Map<String, String> getSeuils() {
		Map<String, String> res = new HashMap<String, String>();
		try {
			Ini ini = new Ini(new File("src/model/data/config.ini"));
			for(String key : ini.get("seuils").keySet()) {
				String value = ini.get("seuils", key);
				res.put(key, value);
			}
			
			
		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return res;
		
	}
	
	/**
	 * Récupère la de la partie "fréquences" du fichier config.ini
	 * 
	 * Utilisé pour rechagé le paramétrage précédent des valeurs
	 * 
	 * @return String la valeur en String (à convertir en float)
	 */
	public String getFrequence() {
		String res = null;
		try {
			Ini ini = new Ini(new File("src/model/data/config.ini"));
			res = ini.get("frequences", "freq-1");
			
		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return res;
	}
}
