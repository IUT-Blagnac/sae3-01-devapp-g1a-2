package application.controller;

import application.view.NoskiaMainFrameController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class NoskiaMainFrame extends Application {
	private Stage primaryStage;

	/**
	 * Appelé au lancement de l'application.
	 * 
	 * Permet de générer la fenêtre principale de l'application via le fichier NoskiaMainFramePane.fxml 
	 * et lance l'initialisation de son texte via sa classe de gestion de la vue 
	 * 
	 * 
	 * @param primaryStage la fenêtre principale de cette page
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		this.primaryStage = primaryStage;
		try {
			FXMLLoader loader = new FXMLLoader(
					NoskiaMainFrameController.class.getResource("../view/NoskiaMainFramePane.fxml"));
			
			BorderPane root = loader.load();
	
			Scene scene = new Scene(root, root.getPrefWidth()+20, root.getPrefHeight()+10);
	
			
			NoskiaMainFrameController apc = loader.getController();
			
			primaryStage.setScene(scene);
			primaryStage.setTitle("Fenêtre Principale");
			
			apc.initContext(primaryStage, this);
			
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * Ouvre la page d'acceuil
	 */
	public static void runApp() {
		Application.launch();
	}

	/**
	 * Créer une page de configuration et lance la fonction qui va lancé son affichage
	 */
	public void startConfiguration() {
		FichierConfig fc = new FichierConfig(this.primaryStage);
		fc.doConfigurationFichierConfig();
		
	}

}
