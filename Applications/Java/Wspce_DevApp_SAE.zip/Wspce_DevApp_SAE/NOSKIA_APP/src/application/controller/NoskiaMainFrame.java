package application.controller;


import java.util.Map;

import application.view.NoskiaMainFrameController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.orm.accessAppPython;

public class NoskiaMainFrame extends Application {
	private Stage primaryStage;
	private NoskiaMainFrameController apc;
	
	private accessAppPython app;
	
	private FichierConfig fc;
	
	private Process processPython;

	/**
	 * Appelé au lancement de l'application.
	 * 
	 * Permet de générer la fenêtre principale de l'application via le fichier NoskiaMainFramePane.fxml 
	 * et lance l'initialisation de son texte via sa classe de gestion de la vue 
	 * 
	 * Initialise les attributes fc (FichierConfig) et app (accessPythonApp)
	 * 
	 * @param primaryStage la fenêtre principale de cette page
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		this.primaryStage = primaryStage;
		try {
			this.fc = new FichierConfig(this.primaryStage, this);
			this.app  = new accessAppPython();
		
			FXMLLoader loader = new FXMLLoader(
					NoskiaMainFrameController.class.getResource("../view/NoskiaMainFramePane.fxml"));
			
			BorderPane root = loader.load();
	
			Scene scene = new Scene(root, root.getPrefWidth()+20, root.getPrefHeight()+10);
	
			
			this.apc = loader.getController();
			
			primaryStage.setScene(scene);
			primaryStage.setTitle("Fenêtre Principale");
			
			this.apc.initContext(primaryStage, this);
			
			
			
			this.apc.displayDialog();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * Ouvre la page d'acceuil
	 */
	public static void runApp() {
		Application.launch();
	}

	/**
	 * Créer une page de configuration et lance la fonction qui va lancé son affichage
	 */
	public void startConfiguration() {
		this.fc.doConfigurationFichierConfig();
	}
	
	/**
	 * Récupère les données sélectionnées lors de la configuration
	 * 
	 * @return une map avec pour clé le nom de la valeur et en valeur true si elle est sélectionnée et false sinon
	 */
	public Map<String, Boolean> getSelectedData(){
		return this.fc.getWantedData();
	}
	
	/**
	 * Fait appel à la méthode qui actualise l'affichage du contenu
	 */
	public void doActualiserAffichageParametre() {
		this.apc.actualiserAffichageParametre();
	}
	
	/**
	 * Appelle la méthode qui lance le timer qui va actualiser le graphique
	 */
	public void doStartTimer() {
		this.apc.startTimer();
	}
	
	/**
	 * Fait appel à la méthode qui lance l'application python
	 */
	public void doStartPythonApp() {	
		this.processPython = this.app.startPythonApp();
	}
	
	/**
	 * Fait appel à la méthode qui stop l'application python si le processus qui exécute le programme python existe
	 */
	public void doStopPythonApp() {
		if(this.processPython != null) {
			this.app.stopPythonApp();
		}
		
	}

}
