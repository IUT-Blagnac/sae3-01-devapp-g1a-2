package application.controller;

import application.view.accueilpanecontroller;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class NoskiaMainFrame extends Application {


	@Override
	public void start(Stage primaryStage) throws Exception {
		
		FXMLLoader loader = new FXMLLoader(
				accueilpanecontroller.class.getResource("../view/accueilpane.fxml"));
		
		BorderPane root = loader.load();

		Scene scene = new Scene(root, root.getPrefWidth()+20, root.getPrefHeight()+10);

		

		primaryStage.setScene(scene);
		primaryStage.setTitle("Fenêtre Principale");
		primaryStage.show();
		
	}

	public static void runApp() {
		Application.launch();
		
	}

	

}
